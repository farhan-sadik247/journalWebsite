"use strict";(()=>{var e={};e.id=386,e.ids=[386],e.modules={11185:e=>{e.exports=require("mongoose")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},80665:e=>{e.exports=require("dns")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},98216:e=>{e.exports=require("net")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},20566:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>x,patchFetch:()=>v,requestAsyncStorage:()=>h,routeModule:()=>m,serverHooks:()=>f,staticGenerationAsyncStorage:()=>y});var o={};r.r(o),r.d(o,{GET:()=>g,POST:()=>u});var s=r(49303),i=r(88716),n=r(60670),a=r(87070),p=r(14184),l=r(3719),d=r(93330),c=r(20471);async function u(e){try{await (0,p.Z)();let{firstName:t,lastName:r,email:o,phone:s,subject:i,message:n}=await e.json();if(!t||!r||!o||!i||!n)return a.NextResponse.json({error:"Missing required fields"},{status:400});if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(o))return a.NextResponse.json({error:"Invalid email format"},{status:400});let u=new l.Z({firstName:t,lastName:r,email:o,phone:s,subject:i,message:n});await u.save();let g=(await d.default.find({$or:[{role:"admin"},{roles:"admin"},{isFounder:!0}]}).select("email name")).map(e=>e.email);if(g.length>0){let e={submission:"Manuscript Submission",review:"Peer Review Process",editorial:"Editorial Inquiry",technical:"Technical Support",partnership:"Partnership Opportunity",other:"Other"},a=await (0,c.C)({to:g,subject:`New Contact Message: ${e[i]}`,html:`
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #2563eb;">New Contact Message Received</h2>
            
            <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3 style="margin: 0 0 15px 0; color: #374151;">Contact Information:</h3>
              <p style="margin: 5px 0;"><strong>Name:</strong> ${t} ${r}</p>
              <p style="margin: 5px 0;"><strong>Email:</strong> ${o}</p>
              ${s?`<p style="margin: 5px 0;"><strong>Phone:</strong> ${s}</p>`:""}
              <p style="margin: 5px 0;"><strong>Subject:</strong> ${e[i]}</p>
              <p style="margin: 5px 0;"><strong>Date:</strong> ${new Date().toLocaleString()}</p>
            </div>
            
            <div style="background: #ffffff; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #e5e7eb;">
              <h3 style="margin: 0 0 15px 0; color: #374151;">Message:</h3>
              <p style="white-space: pre-wrap; line-height: 1.6;">${n}</p>
            </div>
            
            <div style="background: #eff6ff; padding: 15px; border-radius: 8px; margin: 20px 0;">
              <p style="margin: 0; color: #1e40af;">
                <strong>Note:</strong> Please log into the admin dashboard to respond to this message and update its status.
              </p>
            </div>
            
            <p style="margin-top: 30px;">
              Best regards,<br>
              Journal Website System
            </p>
          </div>
        `});a.success||console.error("Failed to send admin notification email:",a.error)}let m=await (0,c.C)({to:o,subject:"Thank you for contacting us",html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #2563eb;">Thank You for Your Message</h2>
          
          <p>Dear ${t} ${r},</p>
          
          <p>Thank you for contacting us. We have received your message and will respond as soon as possible.</p>
          
          <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin: 0 0 10px 0; color: #374151;">Your Message Details:</h3>
            <p style="margin: 5px 0;"><strong>Subject:</strong> ${i}</p>
            <p style="margin: 5px 0;"><strong>Date Submitted:</strong> ${new Date().toLocaleString()}</p>
          </div>
          
          <div style="background: #ecfdf5; padding: 15px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
            <p style="margin: 0; color: #065f46;">
              <strong>What happens next?</strong><br>
              Our team will review your message and respond within 1-2 business days. 
              If your inquiry is urgent, please feel free to contact us directly at the phone numbers listed on our contact page.
            </p>
          </div>
          
          <p>
            If you have any additional questions or need immediate assistance, 
            please don't hesitate to reach out to us directly.
          </p>
          
          <p>
            Best regards,<br>
            Editorial Team<br>
            Research Journal
          </p>
        </div>
      `});return m.success||console.error("Failed to send confirmation email:",m.error),a.NextResponse.json({message:"Message sent successfully",id:u._id},{status:201})}catch(e){return console.error("Error submitting contact message:",e),a.NextResponse.json({error:"Internal server error"},{status:500})}}async function g(e){try{await (0,p.Z)();let{searchParams:t}=new URL(e.url),r=parseInt(t.get("page")||"1"),o=parseInt(t.get("limit")||"10"),s=t.get("status"),i=(r-1)*o,n={};s&&"all"!==s&&(n.status=s);let d=await l.Z.countDocuments(n),c=await l.Z.find(n).sort({createdAt:-1}).skip(i).limit(o).populate("respondedBy","name email").lean();return a.NextResponse.json({messages:c,pagination:{page:r,limit:o,total:d,pages:Math.ceil(d/o)}})}catch(e){return console.error("Error fetching contact messages:",e),a.NextResponse.json({error:"Internal server error"},{status:500})}}let m=new s.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/contact/route",pathname:"/api/contact",filename:"route",bundlePath:"app/api/contact/route"},resolvedPagePath:"E:\\My Projects(personal)\\MyJournalWebsite\\journalWebsite\\src\\app\\api\\contact\\route.ts",nextConfigOutput:"",userland:o}),{requestAsyncStorage:h,staticGenerationAsyncStorage:y,serverHooks:f}=m,x="/api/contact/route";function v(){return(0,n.patchFetch)({serverHooks:f,staticGenerationAsyncStorage:y})}},20471:(e,t,r)=>{r.d(t,{C:()=>s,v:()=>i});let o=r(55245).createTransport({host:process.env.EMAIL_SERVER_HOST,port:parseInt(process.env.EMAIL_SERVER_PORT||"587"),secure:!1,auth:{user:process.env.EMAIL_SERVER_USER,pass:process.env.EMAIL_SERVER_PASSWORD}});async function s(e){try{return await o.sendMail({from:process.env.EMAIL_FROM,to:Array.isArray(e.to)?e.to.join(", "):e.to,subject:e.subject,html:e.html,text:e.text,attachments:e.attachments}),{success:!0}}catch(e){return console.error("Error sending email:",e),{success:!1,error:e}}}let i={manuscriptSubmitted:(e,t,r)=>({subject:"Manuscript Submission Confirmation",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Manuscript Submission Confirmation</h2>
        <p>Dear ${e},</p>
        <p>Thank you for submitting your manuscript to our journal. Your submission has been received and is now under review.</p>
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">Manuscript Details:</h3>
          <p style="margin: 5px 0;"><strong>Title:</strong> ${t}</p>
          <p style="margin: 5px 0;"><strong>Manuscript ID:</strong> ${r}</p>
          <p style="margin: 5px 0;"><strong>Status:</strong> Under Review</p>
        </div>
        <p>You will receive updates on the review process via email. You can also track the status of your submission by logging into your account.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),reviewerInvitation:(e,t,r)=>({subject:"Invitation to Review Manuscript",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Review Invitation</h2>
        <p>Dear ${e},</p>
        <p>You have been invited to review the following manuscript:</p>
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">${t}</h3>
          <p style="margin: 5px 0;"><strong>Review Due Date:</strong> ${r}</p>
        </div>
        <p>Please log into your account to accept or decline this review invitation.</p>
        <p>Thank you for your contribution to the peer review process.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),reviewCompleted:(e,t,r)=>({subject:"Review Completed - Decision Available",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Review Decision Available</h2>
        <p>Dear ${e},</p>
        <p>The peer review for your manuscript has been completed.</p>
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">${t}</h3>
          <p style="margin: 5px 0;"><strong>Decision:</strong> ${r}</p>
        </div>
        <p>Please log into your account to view the detailed review comments and next steps.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),manuscriptAccepted:(e,t)=>({subject:"Manuscript Accepted for Publication",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #10b981;">Manuscript Accepted!</h2>
        <p>Dear ${e},</p>
        <p>Congratulations! Your manuscript has been accepted for publication.</p>
        <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">${t}</h3>
          <p style="margin: 5px 0; color: #065f46;"><strong>Status:</strong> Accepted</p>
        </div>
        <p>Your manuscript will now proceed to the production phase. We will contact you with further details regarding publication timeline and final proofs.</p>
        <p>Thank you for choosing our journal for your research publication.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),contactMessage:(e,t,r,o)=>({subject:`New Contact Message: ${r}`,html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">New Contact Message Received</h2>
        
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 15px 0; color: #374151;">Contact Information:</h3>
          <p style="margin: 5px 0;"><strong>Name:</strong> ${e}</p>
          <p style="margin: 5px 0;"><strong>Email:</strong> ${t}</p>
          <p style="margin: 5px 0;"><strong>Subject:</strong> ${r}</p>
          <p style="margin: 5px 0;"><strong>Date:</strong> ${new Date().toLocaleString()}</p>
        </div>
        
        <div style="background: #ffffff; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #e5e7eb;">
          <h3 style="margin: 0 0 15px 0; color: #374151;">Message:</h3>
          <p style="white-space: pre-wrap; line-height: 1.6;">${o}</p>
        </div>
        
        <div style="background: #eff6ff; padding: 15px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0; color: #1e40af;">
            <strong>Note:</strong> Please log into the admin dashboard to respond to this message.
          </p>
        </div>
        
        <p style="margin-top: 30px;">
          Best regards,<br>
          Journal Website System
        </p>
      </div>
    `})}},14184:(e,t,r)=>{r.d(t,{Z:()=>a});var o=r(11185),s=r.n(o);let i="mongodb+srv://seedswim:icU26sQw3bB8Uocf@gjadt.aswlwco.mongodb.net/journalWebsite?retryWrites=true&w=majority&appName=gjadt";if(!i)throw Error("Please define the MONGODB_URI environment variable inside .env.local");let n=global.mongoose;n||(n=global.mongoose={conn:null,promise:null});let a=async function(){if(n.conn){if(1===s().connection.readyState)return n.conn;n.conn=null,n.promise=null}n.promise||(console.log("Connecting to MongoDB..."),n.promise=s().connect(i,{bufferCommands:!1,serverSelectionTimeoutMS:5e3,connectTimeoutMS:1e4,socketTimeoutMS:45e3}).then(e=>(console.log("MongoDB connected successfully"),e)).catch(e=>{throw console.error("MongoDB connection error:",e),n.promise=null,e}));try{return n.conn=await n.promise,n.conn}catch(e){throw n.promise=null,e}}},3719:(e,t,r)=>{r.d(t,{Z:()=>n});var o=r(11185),s=r.n(o);let i=new(s()).Schema({firstName:{type:String,required:!0,trim:!0},lastName:{type:String,required:!0,trim:!0},email:{type:String,required:!0,lowercase:!0,trim:!0},phone:{type:String,trim:!0},subject:{type:String,required:!0,enum:["submission","review","editorial","technical","partnership","other"]},message:{type:String,required:!0},status:{type:String,enum:["new","read","replied","resolved"],default:"new"},adminResponse:{type:String},respondedBy:{type:s().Schema.Types.ObjectId,ref:"User"},respondedAt:{type:Date}},{timestamps:!0});i.index({status:1,createdAt:-1}),i.index({email:1});let n=s().models.ContactMessage||s().model("ContactMessage",i)},93330:(e,t,r)=>{r.r(t),r.d(t,{default:()=>p});var o=r(11185),s=r.n(o),i=r(42023),n=r.n(i);let a=new(s()).Schema({name:{type:String,required:!0,trim:!0},email:{type:String,required:!0,unique:!0,lowercase:!0,trim:!0},password:{type:String,required:function(){return!this.googleId},minlength:6},googleId:{type:String,sparse:!0},role:{type:String,enum:["author","reviewer","editor","copy-editor","admin"],default:"author"},roles:[{type:String,enum:["author","reviewer","editor","copy-editor","admin"]}],currentActiveRole:{type:String,enum:["author","reviewer","editor","copy-editor","admin"]},isFounder:{type:Boolean,default:!1},profileImage:{type:String,default:""},affiliation:{type:String,default:""},country:{type:String,default:""},bio:{type:String,default:""},expertise:[{type:String}],orcid:{type:String,default:""},designation:{type:String,default:""},designationRole:{type:String,default:""},isEmailVerified:{type:Boolean,default:!1},twoFactorEnabled:{type:Boolean,default:!1},twoFactorSecret:{type:String},resetPasswordToken:{type:String},resetPasswordExpires:{type:Date},emailVerificationToken:{type:String}},{timestamps:!0});a.pre("save",async function(e){if(this.isModified("password")&&this.password)try{let e=await n().genSalt(12);this.password=await n().hash(this.password,e)}catch(t){return e(t)}this.role||(this.role="author"),this.roles&&Array.isArray(this.roles)||(this.roles=[]),0===this.roles.length&&(this.roles=[this.role]),this.currentActiveRole||(this.currentActiveRole=this.role),this.roles.includes(this.currentActiveRole)||this.roles.push(this.currentActiveRole),!this.designation||this.roles.includes("editor")||this.roles.includes("reviewer")||(this.designation="",this.designationRole=""),e()}),a.methods.comparePassword=async function(e){return!!this.password&&n().compare(e,this.password)},a.methods.toJSON=function(){let e=this.toObject();return delete e.password,delete e.twoFactorSecret,delete e.resetPasswordToken,delete e.emailVerificationToken,e};let p=s().models.User||s().model("User",a)}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),o=t.X(0,[9276,5972,2023,5245],()=>r(20566));module.exports=o})();