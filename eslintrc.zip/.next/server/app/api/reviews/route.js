"use strict";(()=>{var e={};e.id=7186,e.ids=[7186],e.modules={11185:e=>{e.exports=require("mongoose")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},27790:e=>{e.exports=require("assert")},78893:e=>{e.exports=require("buffer")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},80665:e=>{e.exports=require("dns")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},98216:e=>{e.exports=require("net")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},86624:e=>{e.exports=require("querystring")},76162:e=>{e.exports=require("stream")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},79891:(e,r,t)=>{t.r(r),t.d(r,{originalPathname:()=>R,patchFetch:()=>S,requestAsyncStorage:()=>y,routeModule:()=>w,serverHooks:()=>b,staticGenerationAsyncStorage:()=>x});var s={};t.r(s),t.d(s,{GET:()=>f,POST:()=>v});var o=t(49303),i=t(88716),n=t(60670),a=t(87070),l=t(45609),u=t(85517),p=t(14184),d=t(17586),c=t(19121),m=t(93330),g=t(20471),h=t(11185);async function f(e){try{let r=await (0,l.getServerSession)(u.L);if(!r)return a.NextResponse.json({error:"Unauthorized"},{status:401});await (0,p.Z)();let{searchParams:t}=new URL(e.url),s=t.get("status"),o=t.get("role"),i=t.get("manuscriptId");console.log("Reviews API called with:",{status:s,role:o,manuscriptId:i,userRoles:r.user.roles,userEmail:r.user.email});let n={};if(i)try{n.manuscriptId=new h.Types.ObjectId(i)}catch(e){return console.error("Invalid manuscriptId format:",i),a.NextResponse.json({error:"Invalid manuscript ID format"},{status:400})}if(r.user.roles?.includes("reviewer"))n.reviewerId=r.user.id;else if(r.user.roles?.includes("editor")||r.user.roles?.includes("admin"));else if(r.user.roles?.includes("author")&&i){let e=await c.default.findById(i);if(!e)return a.NextResponse.json({error:"Manuscript not found"},{status:404});e.authors.some(e=>e.email===r.user.email||"string"==typeof e&&e===r.user.email)||(console.log("Author not authorized for manuscript, checking admin access:",{userEmail:r.user.email,manuscriptAuthors:e.authors.map(e=>e.email||e)}),console.log("Allowing access for admin-level user"))}else{if(!i)return console.log("User does not have sufficient permissions or manuscriptId not provided"),a.NextResponse.json({error:"Insufficient permissions"},{status:403});console.log("User authenticated but roles unclear, allowing manuscript-specific query")}s&&(n.status=s),console.log("Executing query:",JSON.stringify(n));let m=await d.Z.find(n).populate("manuscriptId","title authors status submissionDate category abstract").populate("reviewerId","name email").sort({assignedDate:-1}).lean();console.log("Found reviews:",m.length);let g=m.filter(e=>e.manuscriptId).map(e=>r.user.roles?.includes("author")&&i?{...e,reviewerId:void 0,comments:e.comments?{forAuthors:e.comments.forAuthors,confidentialToEditor:void 0,detailedReview:e.comments.detailedReview}:void 0}:e);return console.log("Filtered reviews (excluding null manuscriptId):",g.length),a.NextResponse.json({reviews:g})}catch(e){return console.error("Error fetching reviews:",e),a.NextResponse.json({error:"Internal server error"},{status:500})}}async function v(e){try{let r=await (0,l.getServerSession)(u.L);if(!r||!(r.user.roles?.includes("editor")||r.user.roles?.includes("admin")))return a.NextResponse.json({error:"Unauthorized"},{status:401});await (0,p.Z)();let{manuscriptId:t,reviewerId:s,type:o,dueDate:i}=await e.json();if(!t||!s||!o)return a.NextResponse.json({error:"Missing required fields"},{status:400});let n=await c.default.findById(t);if(!n)return a.NextResponse.json({error:"Manuscript not found"},{status:404});if("published"===n.status)return a.NextResponse.json({error:"Cannot assign reviewers to published manuscripts",manuscriptStatus:n.status},{status:400});let h=await m.default.findById(s);if(!h)return a.NextResponse.json({error:"Reviewer not found"},{status:400});if(!(h.roles?.includes("reviewer")||"reviewer"===h.role))return a.NextResponse.json({error:"User is not a reviewer"},{status:400});if(await d.Z.findOne({manuscriptId:t,reviewerId:s}))return a.NextResponse.json({error:"Review already assigned to this reviewer"},{status:400});let f=new d.Z({manuscriptId:t,reviewerId:s,assignedBy:r.user.id,type:o,dueDate:i||new Date(Date.now()+12096e5),status:"pending"});await f.save(),"submitted"===n.status&&(n.status="under-review",await n.save());try{await (0,g.C)({to:h.email,subject:"New Review Assignment - Research Journal",html:`
          <h2>New Review Assignment</h2>
          <p>Dear ${h.name},</p>
          <p>You have been assigned to review the manuscript: <strong>${n.title}</strong></p>
          <p><strong>Review Type:</strong> ${f.type}</p>
          <p><strong>Due Date:</strong> ${f.dueDate.toLocaleDateString()}</p>
          <p>Please log in to your dashboard to access the manuscript and begin your review:</p>
          <p><a href="https://gjadt.org/dashboard/reviews/${f._id}">Review Manuscript</a></p>
          <p>Best regards,<br>Editorial Team</p>
        `})}catch(e){console.error("Failed to send email notification:",e)}return a.NextResponse.json({message:"Review assigned successfully",review:f.toObject()})}catch(e){return console.error("Error creating review assignment:",e),a.NextResponse.json({error:"Internal server error"},{status:500})}}let w=new o.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/reviews/route",pathname:"/api/reviews",filename:"route",bundlePath:"app/api/reviews/route"},resolvedPagePath:"E:\\My Projects(personal)\\MyJournalWebsite\\journalWebsite\\src\\app\\api\\reviews\\route.ts",nextConfigOutput:"",userland:s}),{requestAsyncStorage:y,staticGenerationAsyncStorage:x,serverHooks:b}=w,R="/api/reviews/route";function S(){return(0,n.patchFetch)({serverHooks:b,staticGenerationAsyncStorage:x})}},20471:(e,r,t)=>{t.d(r,{C:()=>o,v:()=>i});let s=t(55245).createTransport({host:process.env.EMAIL_SERVER_HOST,port:parseInt(process.env.EMAIL_SERVER_PORT||"587"),secure:!1,auth:{user:process.env.EMAIL_SERVER_USER,pass:process.env.EMAIL_SERVER_PASSWORD}});async function o(e){try{return await s.sendMail({from:process.env.EMAIL_FROM,to:Array.isArray(e.to)?e.to.join(", "):e.to,subject:e.subject,html:e.html,text:e.text,attachments:e.attachments}),{success:!0}}catch(e){return console.error("Error sending email:",e),{success:!1,error:e}}}let i={manuscriptSubmitted:(e,r,t)=>({subject:"Manuscript Submission Confirmation",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Manuscript Submission Confirmation</h2>
        <p>Dear ${e},</p>
        <p>Thank you for submitting your manuscript to our journal. Your submission has been received and is now under review.</p>
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">Manuscript Details:</h3>
          <p style="margin: 5px 0;"><strong>Title:</strong> ${r}</p>
          <p style="margin: 5px 0;"><strong>Manuscript ID:</strong> ${t}</p>
          <p style="margin: 5px 0;"><strong>Status:</strong> Under Review</p>
        </div>
        <p>You will receive updates on the review process via email. You can also track the status of your submission by logging into your account.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),reviewerInvitation:(e,r,t)=>({subject:"Invitation to Review Manuscript",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Review Invitation</h2>
        <p>Dear ${e},</p>
        <p>You have been invited to review the following manuscript:</p>
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">${r}</h3>
          <p style="margin: 5px 0;"><strong>Review Due Date:</strong> ${t}</p>
        </div>
        <p>Please log into your account to accept or decline this review invitation.</p>
        <p>Thank you for your contribution to the peer review process.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),reviewCompleted:(e,r,t)=>({subject:"Review Completed - Decision Available",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Review Decision Available</h2>
        <p>Dear ${e},</p>
        <p>The peer review for your manuscript has been completed.</p>
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">${r}</h3>
          <p style="margin: 5px 0;"><strong>Decision:</strong> ${t}</p>
        </div>
        <p>Please log into your account to view the detailed review comments and next steps.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),manuscriptAccepted:(e,r)=>({subject:"Manuscript Accepted for Publication",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #10b981;">Manuscript Accepted!</h2>
        <p>Dear ${e},</p>
        <p>Congratulations! Your manuscript has been accepted for publication.</p>
        <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">${r}</h3>
          <p style="margin: 5px 0; color: #065f46;"><strong>Status:</strong> Accepted</p>
        </div>
        <p>Your manuscript will now proceed to the production phase. We will contact you with further details regarding publication timeline and final proofs.</p>
        <p>Thank you for choosing our journal for your research publication.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),contactMessage:(e,r,t,s)=>({subject:`New Contact Message: ${t}`,html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">New Contact Message Received</h2>
        
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 15px 0; color: #374151;">Contact Information:</h3>
          <p style="margin: 5px 0;"><strong>Name:</strong> ${e}</p>
          <p style="margin: 5px 0;"><strong>Email:</strong> ${r}</p>
          <p style="margin: 5px 0;"><strong>Subject:</strong> ${t}</p>
          <p style="margin: 5px 0;"><strong>Date:</strong> ${new Date().toLocaleString()}</p>
        </div>
        
        <div style="background: #ffffff; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #e5e7eb;">
          <h3 style="margin: 0 0 15px 0; color: #374151;">Message:</h3>
          <p style="white-space: pre-wrap; line-height: 1.6;">${s}</p>
        </div>
        
        <div style="background: #eff6ff; padding: 15px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0; color: #1e40af;">
            <strong>Note:</strong> Please log into the admin dashboard to respond to this message.
          </p>
        </div>
        
        <p style="margin-top: 30px;">
          Best regards,<br>
          Journal Website System
        </p>
      </div>
    `})}},14184:(e,r,t)=>{t.d(r,{Z:()=>a});var s=t(11185),o=t.n(s);let i="mongodb+srv://seedswim:icU26sQw3bB8Uocf@gjadt.aswlwco.mongodb.net/journalWebsite?retryWrites=true&w=majority&appName=gjadt";if(!i)throw Error("Please define the MONGODB_URI environment variable inside .env.local");let n=global.mongoose;n||(n=global.mongoose={conn:null,promise:null});let a=async function(){if(n.conn){if(1===o().connection.readyState)return n.conn;n.conn=null,n.promise=null}n.promise||(console.log("Connecting to MongoDB..."),n.promise=o().connect(i,{bufferCommands:!1,serverSelectionTimeoutMS:5e3,connectTimeoutMS:1e4,socketTimeoutMS:45e3}).then(e=>(console.log("MongoDB connected successfully"),e)).catch(e=>{throw console.error("MongoDB connection error:",e),n.promise=null,e}));try{return n.conn=await n.promise,n.conn}catch(e){throw n.promise=null,e}}},93330:(e,r,t)=>{t.r(r),t.d(r,{default:()=>l});var s=t(11185),o=t.n(s),i=t(42023),n=t.n(i);let a=new(o()).Schema({name:{type:String,required:!0,trim:!0},email:{type:String,required:!0,unique:!0,lowercase:!0,trim:!0},password:{type:String,required:function(){return!this.googleId},minlength:6},googleId:{type:String,sparse:!0},role:{type:String,enum:["author","reviewer","editor","copy-editor","admin"],default:"author"},roles:[{type:String,enum:["author","reviewer","editor","copy-editor","admin"]}],currentActiveRole:{type:String,enum:["author","reviewer","editor","copy-editor","admin"]},isFounder:{type:Boolean,default:!1},profileImage:{type:String,default:""},affiliation:{type:String,default:""},country:{type:String,default:""},bio:{type:String,default:""},expertise:[{type:String}],orcid:{type:String,default:""},designation:{type:String,default:""},designationRole:{type:String,default:""},isEmailVerified:{type:Boolean,default:!1},twoFactorEnabled:{type:Boolean,default:!1},twoFactorSecret:{type:String},resetPasswordToken:{type:String},resetPasswordExpires:{type:Date},emailVerificationToken:{type:String}},{timestamps:!0});a.pre("save",async function(e){if(this.isModified("password")&&this.password)try{let e=await n().genSalt(12);this.password=await n().hash(this.password,e)}catch(r){return e(r)}this.role||(this.role="author"),this.roles&&Array.isArray(this.roles)||(this.roles=[]),0===this.roles.length&&(this.roles=[this.role]),this.currentActiveRole||(this.currentActiveRole=this.role),this.roles.includes(this.currentActiveRole)||this.roles.push(this.currentActiveRole),!this.designation||this.roles.includes("editor")||this.roles.includes("reviewer")||(this.designation="",this.designationRole=""),e()}),a.methods.comparePassword=async function(e){return!!this.password&&n().compare(e,this.password)},a.methods.toJSON=function(){let e=this.toObject();return delete e.password,delete e.twoFactorSecret,delete e.resetPasswordToken,delete e.emailVerificationToken,e};let l=o().models.User||o().model("User",a)}};var r=require("../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),s=r.X(0,[9276,5972,2023,1734,5245,9485],()=>t(79891));module.exports=s})();