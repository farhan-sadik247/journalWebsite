"use strict";(()=>{var e={};e.id=380,e.ids=[380],e.modules={11185:e=>{e.exports=require("mongoose")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},27790:e=>{e.exports=require("assert")},78893:e=>{e.exports=require("buffer")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},80665:e=>{e.exports=require("dns")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},98216:e=>{e.exports=require("net")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},86624:e=>{e.exports=require("querystring")},76162:e=>{e.exports=require("stream")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},4648:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>S,patchFetch:()=>I,requestAsyncStorage:()=>R,routeModule:()=>j,serverHooks:()=>q,staticGenerationAsyncStorage:()=>E});var i={};r.r(i),r.d(i,{GET:()=>w,PUT:()=>x});var o=r(49303),s=r(88716),a=r(60670),n=r(87070),p=r(45609),c=r(85517),u=r(14184),d=r(11185),l=r.n(d),m=r(17586),g=r(19121),h=r(93330),f=r(45535),y=r(20471),v=r(91816);async function w(e,{params:t}){try{let e=await (0,p.getServerSession)(c.L);if(!e)return n.NextResponse.json({error:"Unauthorized"},{status:401});await (0,u.Z)();let r=await m.Z.findById(t.id).populate("manuscriptId","title abstract authors keywords submissionDate files").populate("reviewerId","name email").populate("assignedBy","name email");if(!r)return n.NextResponse.json({error:"Review not found"},{status:404});if(!(r.reviewerId._id.toString()===e.user.id||e.user.roles?.includes("editor")||e.user.roles?.includes("admin")||e.user.roles?.includes("author")&&r.manuscriptId.authors.some(t=>t.email===e.user.email)))return n.NextResponse.json({error:"Insufficient permissions"},{status:403});return n.NextResponse.json({review:r.toObject()})}catch(e){return console.error("Error fetching review:",e),n.NextResponse.json({error:"Internal server error"},{status:500})}}async function x(e,{params:t}){try{let r;let i=await (0,p.getServerSession)(c.L);if(!i)return n.NextResponse.json({error:"Unauthorized"},{status:401});let{id:o}=t;if(!i?.user)return n.NextResponse.json({error:"Not authenticated"},{status:401});let{comments:s,confidentialComments:a,recommendation:d,technicalQuality:l,novelty:f,significance:w,clarity:x,overallScore:j}=await e.json();await (0,u.Z)();let R=await m.Z.findById(o).populate("manuscriptId").populate("reviewerId").populate("assignedBy");if(!R)return n.NextResponse.json({error:"Review not found"},{status:404});if(R.reviewerId._id.toString()!==i.user.id&&!i.user.roles?.includes("admin"))return n.NextResponse.json({error:"Not authorized to submit this review"},{status:403});R.comments=s,R.confidentialComments=a,R.recommendation=d,R.ratings={technicalQuality:l||5,novelty:f||5,significance:w||5,clarity:x||5,overall:j||5},R.status="completed";try{await R.save()}catch(e){return console.error("Error saving review:",e),n.NextResponse.json({error:"Error saving review"},{status:500})}try{let e=R.manuscriptId,t=await h.default.findById(R.reviewerId);if(e.authors&&Array.isArray(e.authors)){for(let r of e.authors)if(r.email){try{await (0,v.uq)(r.email,e._id.toString(),e.title,t?.name)}catch(e){console.error("Error sending in-app notification:",e)}try{let i=t?.name?` by ${t.name}`:"",o=await (0,y.C)({to:r.email,subject:`Review Submitted for Your Manuscript: ${e.title}`,html:`
                  <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #2c3e50;">Review Submitted</h2>
                    <p>Dear ${r.name||"Author"},</p>
                    <p>We wanted to inform you that a review has been submitted${i} for your manuscript:</p>
                    <div style="background-color: #f8f9fa; padding: 15px; border-left: 4px solid #007bff; margin: 20px 0;">
                      <strong>"${e.title}"</strong>
                    </div>
                    <p>The editorial team will now review the feedback and make a decision on the next steps for your manuscript. You will receive another notification once the editorial decision has been made.</p>
                    <p>You can view the status of your manuscript in your dashboard:</p>
                    <p style="text-align: center; margin: 25px 0;">
                      <a href="https://gjadt.org/dashboard/manuscripts/${e._id}" 
                         style="background-color: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block;">
                        View Manuscript Status
                      </a>
                    </p>
                    <p>Thank you for your submission to our journal.</p>
                    <hr style="margin: 30px 0; border: none; border-top: 1px solid #dee2e6;">
                    <p style="font-size: 12px; color: #6c757d;">
                      This is an automated message from the journal submission system. Please do not reply to this email.
                    </p>
                  </div>
                `,text:`A review has been submitted${i} for your manuscript "${e.title}". The editorial team will review the feedback and update you on the next steps. You can view your manuscript status at: https://gjadt.org/dashboard/manuscripts/${e._id}`});o.success||console.warn("Email failed to send but continuing with review submission:",o.error)}catch(e){console.error("Error sending email notification:",e)}}}}catch(e){console.error("Error in author notification process:",e)}try{r=await g.default.findById(R.manuscriptId._id);let e=(await m.Z.find({manuscriptId:R.manuscriptId._id})).filter(e=>"completed"===e.status),t=!1,o=r.status;if(e.length>=1){if(e.length>=2)o=function(e){let t=e.map(e=>e.recommendation),r=t.filter(e=>"accept"===e).length,i=t.filter(e=>"reject"===e).length,o=t.filter(e=>"major-revision"===e).length,s=t.filter(e=>"minor-revision"===e).length;return r>=Math.ceil(e.length/2)?"accepted":i>=Math.ceil(e.length/2)?"rejected":o>0?"major-revision-requested":s>0?"minor-revision-requested":"under-editorial-review"}(e),t=!0;else if(1===e.length){let r=e[0].recommendation;"accept"===r?(o="accepted",t=!0):"reject"===r?(o="rejected",t=!0):"major-revision"===r?(o="major-revision-requested",t=!0):"minor-revision"===r&&(o="minor-revision-requested",t=!0)}}if(t&&o!==r.status){let t=r.status;r.status=o,r.timeline.push({event:"status-change",description:`Status changed to ${o} based on review recommendations`,performedBy:i.user.id,metadata:{previousStatus:t,newStatus:o,reviewCount:e.length,recommendations:e.map(e=>e.recommendation),triggeredBy:"review-completion",reviewerId:i.user.id}});try{console.log("Saving manuscript with updated timeline:",{manuscriptId:r._id,newStatus:o,timelineEntryCount:r.timeline.length}),await r.save(),console.log("Manuscript saved successfully")}catch(e){console.error("Error saving manuscript with timeline update:",e)}if("accepted"===o)try{await b(r,i.user.id)}catch(e){console.error("Error in accepted manuscript workflow:",e)}}if("accept"===d)try{await b(r)}catch(e){console.error("Error sending accept review notifications:",e)}}catch(e){console.error("Error processing manuscript status updates:",e)}if(R.assignedBy&&R.assignedBy.email)try{let e=await (0,y.C)({to:R.assignedBy.email,subject:`Review Completed - ${R.manuscriptId.title}`,html:`
            <h2>Review Completed</h2>
            <p>Dear ${R.assignedBy.name},</p>
            <p>A review has been completed for the manuscript: <strong>${R.manuscriptId.title}</strong></p>
            <p><strong>Recommendation:</strong> ${d}</p>
            <p>Please log in to your editorial dashboard to view the full review and make editorial decisions.</p>
            <p><a href="https://gjadt.org/dashboard/editor">View Editorial Dashboard</a></p>
            <p>Best regards,<br>Journal System</p>
          `});e.success||console.warn("Email to editor failed to send but continuing with review submission:",e.error)}catch(e){console.log("Email notification to editor failed (non-critical):",e.message)}return n.NextResponse.json({message:"Review submitted successfully",review:R.toObject()})}catch(e){return console.error("Error submitting review:",e),n.NextResponse.json({error:"Internal server error"},{status:500})}}async function b(e,t){try{let r=e.authors.find(e=>e.isCorresponding);if(!r){console.error("No corresponding author found for accepted manuscript");return}if((await f.Z.find({relatedManuscript:e._id,type:{$in:["manuscript_status","payment_required"]},title:{$regex:/accepted|payment/i}}).sort({createdAt:-1}).limit(5)).filter(e=>Date.now()-new Date(e.createdAt).getTime()<864e5).length>=2){console.log("Acceptance notifications already sent recently, skipping duplicate notifications");return}e.timeline.push({event:"accepted",description:"Manuscript accepted and moved to publication queue",performedBy:t||new(l()).Types.ObjectId,metadata:{acceptedDate:new Date,nextStep:"payment-required",triggeredBy:t?"review-completion":"system"}}),e.status="accepted",await e.save();let i={articleType:e.category||"research",authorCountry:r.country||"US",institutionName:r.affiliation};try{let t=await (0,v.P$)(r.email,e._id.toString(),e.title,i);console.log("Acceptance notifications sent successfully:",{acceptance:t.acceptanceNotification?._id,payment:t.paymentNotification?._id,feeWaived:t.feeCalculation?.isWaiver||!1})}catch(e){console.error("Error sending acceptance notifications:",e)}}catch(e){console.error("Error in handleAcceptedManuscript function:",e)}}let j=new o.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/reviews/[id]/route",pathname:"/api/reviews/[id]",filename:"route",bundlePath:"app/api/reviews/[id]/route"},resolvedPagePath:"E:\\My Projects(personal)\\MyJournalWebsite\\journalWebsite\\src\\app\\api\\reviews\\[id]\\route.ts",nextConfigOutput:"",userland:i}),{requestAsyncStorage:R,staticGenerationAsyncStorage:E,serverHooks:q}=j,S="/api/reviews/[id]/route";function I(){return(0,a.patchFetch)({serverHooks:q,staticGenerationAsyncStorage:E})}},20471:(e,t,r)=>{r.d(t,{C:()=>o,v:()=>s});let i=r(55245).createTransport({host:process.env.EMAIL_SERVER_HOST,port:parseInt(process.env.EMAIL_SERVER_PORT||"587"),secure:!1,auth:{user:process.env.EMAIL_SERVER_USER,pass:process.env.EMAIL_SERVER_PASSWORD}});async function o(e){try{return await i.sendMail({from:process.env.EMAIL_FROM,to:Array.isArray(e.to)?e.to.join(", "):e.to,subject:e.subject,html:e.html,text:e.text,attachments:e.attachments}),{success:!0}}catch(e){return console.error("Error sending email:",e),{success:!1,error:e}}}let s={manuscriptSubmitted:(e,t,r)=>({subject:"Manuscript Submission Confirmation",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Manuscript Submission Confirmation</h2>
        <p>Dear ${e},</p>
        <p>Thank you for submitting your manuscript to our journal. Your submission has been received and is now under review.</p>
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">Manuscript Details:</h3>
          <p style="margin: 5px 0;"><strong>Title:</strong> ${t}</p>
          <p style="margin: 5px 0;"><strong>Manuscript ID:</strong> ${r}</p>
          <p style="margin: 5px 0;"><strong>Status:</strong> Under Review</p>
        </div>
        <p>You will receive updates on the review process via email. You can also track the status of your submission by logging into your account.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),reviewerInvitation:(e,t,r)=>({subject:"Invitation to Review Manuscript",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Review Invitation</h2>
        <p>Dear ${e},</p>
        <p>You have been invited to review the following manuscript:</p>
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">${t}</h3>
          <p style="margin: 5px 0;"><strong>Review Due Date:</strong> ${r}</p>
        </div>
        <p>Please log into your account to accept or decline this review invitation.</p>
        <p>Thank you for your contribution to the peer review process.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),reviewCompleted:(e,t,r)=>({subject:"Review Completed - Decision Available",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Review Decision Available</h2>
        <p>Dear ${e},</p>
        <p>The peer review for your manuscript has been completed.</p>
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">${t}</h3>
          <p style="margin: 5px 0;"><strong>Decision:</strong> ${r}</p>
        </div>
        <p>Please log into your account to view the detailed review comments and next steps.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),manuscriptAccepted:(e,t)=>({subject:"Manuscript Accepted for Publication",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #10b981;">Manuscript Accepted!</h2>
        <p>Dear ${e},</p>
        <p>Congratulations! Your manuscript has been accepted for publication.</p>
        <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">${t}</h3>
          <p style="margin: 5px 0; color: #065f46;"><strong>Status:</strong> Accepted</p>
        </div>
        <p>Your manuscript will now proceed to the production phase. We will contact you with further details regarding publication timeline and final proofs.</p>
        <p>Thank you for choosing our journal for your research publication.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),contactMessage:(e,t,r,i)=>({subject:`New Contact Message: ${r}`,html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">New Contact Message Received</h2>
        
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 15px 0; color: #374151;">Contact Information:</h3>
          <p style="margin: 5px 0;"><strong>Name:</strong> ${e}</p>
          <p style="margin: 5px 0;"><strong>Email:</strong> ${t}</p>
          <p style="margin: 5px 0;"><strong>Subject:</strong> ${r}</p>
          <p style="margin: 5px 0;"><strong>Date:</strong> ${new Date().toLocaleString()}</p>
        </div>
        
        <div style="background: #ffffff; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #e5e7eb;">
          <h3 style="margin: 0 0 15px 0; color: #374151;">Message:</h3>
          <p style="white-space: pre-wrap; line-height: 1.6;">${i}</p>
        </div>
        
        <div style="background: #eff6ff; padding: 15px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0; color: #1e40af;">
            <strong>Note:</strong> Please log into the admin dashboard to respond to this message.
          </p>
        </div>
        
        <p style="margin-top: 30px;">
          Best regards,<br>
          Journal Website System
        </p>
      </div>
    `})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[9276,5972,2023,1734,5245,1816,9485],()=>r(4648));module.exports=i})();