"use strict";(()=>{var e={};e.id=4497,e.ids=[4497],e.modules={11185:e=>{e.exports=require("mongoose")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},27790:e=>{e.exports=require("assert")},78893:e=>{e.exports=require("buffer")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},80665:e=>{e.exports=require("dns")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},98216:e=>{e.exports=require("net")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},86624:e=>{e.exports=require("querystring")},76162:e=>{e.exports=require("stream")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},84884:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>w,patchFetch:()=>S,requestAsyncStorage:()=>x,routeModule:()=>f,serverHooks:()=>b,staticGenerationAsyncStorage:()=>v});var i={};r.r(i),r.d(i,{POST:()=>y});var o=r(49303),s=r(88716),n=r(60670),a=r(87070),p=r(75571),l=r(85517),d=r(14184),c=r(19121),u=r(17586),m=r(20471),g=r(11185),h=r.n(g);async function y(e,{params:t}){try{let r=await (0,p.getServerSession)(l.L);if(!r)return a.NextResponse.json({error:"Unauthorized"},{status:401});if(!r.user.roles?.includes("editor")&&!r.user.roles?.includes("admin"))return a.NextResponse.json({error:"Insufficient permissions"},{status:403});if(!t.id||!h().Types.ObjectId.isValid(t.id))return a.NextResponse.json({error:"Invalid manuscript ID"},{status:400});let{decision:i,editorComments:o,confidentialNotes:s,includeReviewerComments:n,customMessage:g}=await e.json();if(!i||!o)return a.NextResponse.json({error:"Decision and editor comments are required"},{status:400});await (0,d.Z)();let y=await c.default.findById(t.id).populate("submittedBy","name email").lean();if(!y)return a.NextResponse.json({error:"Manuscript not found"},{status:404});let f=[];n&&(f=await u.Z.find({manuscriptId:t.id,status:"completed"}).select("recommendation ratings comments").lean());let x=y.status;switch(i){case"accept":x="accepted";break;case"minor-revision":case"major-revision":x="revision-requested";break;case"reject":x="rejected"}await c.default.findByIdAndUpdate(t.id,{status:x,$push:{timeline:{event:"editorial-decision",description:`Editorial decision: ${i}`,performedBy:new(h()).Types.ObjectId(r.user.id),metadata:{decision:i,editorComments:o,confidentialNotes:s,includeReviewerComments:n}}}});try{let e=y.submittedBy?.email,t=y.submittedBy?.name;if(e&&t){let r=function(e,t,r,i,o,s,n){let a={accept:"Accepted","minor-revision":"Minor Revisions Required","major-revision":"Major Revisions Required",reject:"Rejected"},p={accept:"#10b981","minor-revision":"#f59e0b","major-revision":"#ef4444",reject:"#dc2626"},l=`Editorial Decision: ${a[r]} - ${t}`,d="";s.length>0&&(d=`
      <div style="margin: 20px 0;">
        <h3 style="color: #374151; margin-bottom: 15px;">Reviewer Comments:</h3>
        ${s.map((e,t)=>`
          <div style="background: #f9fafb; padding: 15px; border-radius: 8px; margin-bottom: 15px; border-left: 3px solid #2563eb;">
            <h4 style="margin: 0 0 10px 0; color: #1f2937;">Review ${t+1}</h4>
            <p style="margin: 5px 0;"><strong>Recommendation:</strong> ${e.recommendation?.replace("-"," ")||"N/A"}</p>
            ${e.ratings?`
              <p style="margin: 5px 0;"><strong>Overall Rating:</strong> ${e.ratings.overall||"N/A"}/10</p>
            `:""}
            ${e.comments?.forAuthors?`
              <div style="margin-top: 10px;">
                <strong>Comments:</strong>
                <p style="margin: 5px 0; line-height: 1.6;">${e.comments.forAuthors}</p>
              </div>
            `:""}
          </div>
        `).join("")}
      </div>
    `);let c="accept"===r?`
    <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
      <h3 style="margin: 0 0 10px 0; color: #065f46;">Next Steps:</h3>
      <p style="margin: 5px 0; color: #065f46;">Your manuscript has been accepted for publication! Our production team will contact you soon regarding:</p>
      <ul style="margin: 10px 0; color: #065f46;">
        <li>Copy-editing process</li>
        <li>Proof review</li>
        <li>Publication timeline</li>
        <li>Copyright agreement</li>
      </ul>
    </div>
  `:r.includes("revision")?`
    <div style="background: #fef3c7; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #f59e0b;">
      <h3 style="margin: 0 0 10px 0; color: #92400e;">Revision Instructions:</h3>
      <p style="margin: 5px 0; color: #92400e;">Please address the comments and resubmit your revised manuscript through our submission system.</p>
      <p style="margin: 5px 0; color: #92400e;"><strong>Revision Deadline:</strong> 60 days from this notification</p>
      <p style="margin: 5px 0; color: #92400e;">Please include a detailed response letter explaining how you addressed each comment.</p>
    </div>
  `:"";return{subject:l,html:`
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: ${p[r]};">Editorial Decision</h2>
      <p>Dear ${e},</p>
      
      <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3 style="margin: 0 0 10px 0; color: #374151;">Manuscript: ${t}</h3>
        <p style="margin: 5px 0;"><strong>Manuscript ID:</strong> ${n}</p>
        <p style="margin: 5px 0;"><strong>Decision:</strong> <span style="color: ${p[r]}; font-weight: 600;">${a[r]}</span></p>
      </div>

      <div style="margin: 20px 0;">
        <h3 style="color: #374151; margin-bottom: 10px;">Editor Comments:</h3>
        <div style="background: white; padding: 15px; border-radius: 8px; border-left: 3px solid #2563eb; line-height: 1.6;">
          ${i.replace(/\n/g,"<br>")}
        </div>
      </div>

      ${o?`
        <div style="margin: 20px 0;">
          <h3 style="color: #374151; margin-bottom: 10px;">Additional Message:</h3>
          <div style="background: #f0f9ff; padding: 15px; border-radius: 8px; border-left: 3px solid #0ea5e9; line-height: 1.6;">
            ${o.replace(/\n/g,"<br>")}
          </div>
        </div>
      `:""}

      ${d}
      
      ${c}

      <p style="margin-top: 30px;">
        You can log into your account to view the full decision details and take any necessary actions.
      </p>
      
      <p style="margin-top: 20px;">
        <a href="https://gjadt.org/dashboard/manuscripts/${n}" 
           style="background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
          View Manuscript Details
        </a>
      </p>

      <p style="margin-top: 30px;">Best regards,<br>Editorial Team</p>
    </div>
  `}}(t,y.title,i,o,g,f,y._id.toString());await (0,m.C)({to:e,subject:r.subject,html:r.html})}}catch(e){console.error("Failed to send decision email:",e)}return a.NextResponse.json({message:"Editorial decision submitted successfully",decision:{manuscriptId:t.id,decision:i,status:x,timestamp:new Date}})}catch(e){return console.error("Error submitting editorial decision:",e),a.NextResponse.json({error:"Internal server error"},{status:500})}}let f=new o.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/manuscripts/[id]/decision/route",pathname:"/api/manuscripts/[id]/decision",filename:"route",bundlePath:"app/api/manuscripts/[id]/decision/route"},resolvedPagePath:"E:\\My Projects(personal)\\MyJournalWebsite\\journalWebsite\\src\\app\\api\\manuscripts\\[id]\\decision\\route.ts",nextConfigOutput:"",userland:i}),{requestAsyncStorage:x,staticGenerationAsyncStorage:v,serverHooks:b}=f,w="/api/manuscripts/[id]/decision/route";function S(){return(0,n.patchFetch)({serverHooks:b,staticGenerationAsyncStorage:v})}},20471:(e,t,r)=>{r.d(t,{C:()=>o,v:()=>s});let i=r(55245).createTransport({host:process.env.EMAIL_SERVER_HOST,port:parseInt(process.env.EMAIL_SERVER_PORT||"587"),secure:!1,auth:{user:process.env.EMAIL_SERVER_USER,pass:process.env.EMAIL_SERVER_PASSWORD}});async function o(e){try{return await i.sendMail({from:process.env.EMAIL_FROM,to:Array.isArray(e.to)?e.to.join(", "):e.to,subject:e.subject,html:e.html,text:e.text,attachments:e.attachments}),{success:!0}}catch(e){return console.error("Error sending email:",e),{success:!1,error:e}}}let s={manuscriptSubmitted:(e,t,r)=>({subject:"Manuscript Submission Confirmation",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Manuscript Submission Confirmation</h2>
        <p>Dear ${e},</p>
        <p>Thank you for submitting your manuscript to our journal. Your submission has been received and is now under review.</p>
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">Manuscript Details:</h3>
          <p style="margin: 5px 0;"><strong>Title:</strong> ${t}</p>
          <p style="margin: 5px 0;"><strong>Manuscript ID:</strong> ${r}</p>
          <p style="margin: 5px 0;"><strong>Status:</strong> Under Review</p>
        </div>
        <p>You will receive updates on the review process via email. You can also track the status of your submission by logging into your account.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),reviewerInvitation:(e,t,r)=>({subject:"Invitation to Review Manuscript",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Review Invitation</h2>
        <p>Dear ${e},</p>
        <p>You have been invited to review the following manuscript:</p>
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">${t}</h3>
          <p style="margin: 5px 0;"><strong>Review Due Date:</strong> ${r}</p>
        </div>
        <p>Please log into your account to accept or decline this review invitation.</p>
        <p>Thank you for your contribution to the peer review process.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),reviewCompleted:(e,t,r)=>({subject:"Review Completed - Decision Available",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Review Decision Available</h2>
        <p>Dear ${e},</p>
        <p>The peer review for your manuscript has been completed.</p>
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">${t}</h3>
          <p style="margin: 5px 0;"><strong>Decision:</strong> ${r}</p>
        </div>
        <p>Please log into your account to view the detailed review comments and next steps.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),manuscriptAccepted:(e,t)=>({subject:"Manuscript Accepted for Publication",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #10b981;">Manuscript Accepted!</h2>
        <p>Dear ${e},</p>
        <p>Congratulations! Your manuscript has been accepted for publication.</p>
        <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">${t}</h3>
          <p style="margin: 5px 0; color: #065f46;"><strong>Status:</strong> Accepted</p>
        </div>
        <p>Your manuscript will now proceed to the production phase. We will contact you with further details regarding publication timeline and final proofs.</p>
        <p>Thank you for choosing our journal for your research publication.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),contactMessage:(e,t,r,i)=>({subject:`New Contact Message: ${r}`,html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">New Contact Message Received</h2>
        
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 15px 0; color: #374151;">Contact Information:</h3>
          <p style="margin: 5px 0;"><strong>Name:</strong> ${e}</p>
          <p style="margin: 5px 0;"><strong>Email:</strong> ${t}</p>
          <p style="margin: 5px 0;"><strong>Subject:</strong> ${r}</p>
          <p style="margin: 5px 0;"><strong>Date:</strong> ${new Date().toLocaleString()}</p>
        </div>
        
        <div style="background: #ffffff; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #e5e7eb;">
          <h3 style="margin: 0 0 15px 0; color: #374151;">Message:</h3>
          <p style="white-space: pre-wrap; line-height: 1.6;">${i}</p>
        </div>
        
        <div style="background: #eff6ff; padding: 15px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0; color: #1e40af;">
            <strong>Note:</strong> Please log into the admin dashboard to respond to this message.
          </p>
        </div>
        
        <p style="margin-top: 30px;">
          Best regards,<br>
          Journal Website System
        </p>
      </div>
    `})}},14184:(e,t,r)=>{r.d(t,{Z:()=>a});var i=r(11185),o=r.n(i);let s="mongodb+srv://fsadik2319:v17Ad1JygFqbVPWd@journalweb1.oeyvwhv.mongodb.net/?retryWrites=true&w=majority&appName=journalweb1";if(!s)throw Error("Please define the MONGODB_URI environment variable inside .env.local");let n=global.mongoose;n||(n=global.mongoose={conn:null,promise:null});let a=async function(){if(n.conn){if(1===o().connection.readyState)return n.conn;n.conn=null,n.promise=null}n.promise||(console.log("Connecting to MongoDB..."),n.promise=o().connect(s,{bufferCommands:!1,serverSelectionTimeoutMS:5e3,connectTimeoutMS:1e4,socketTimeoutMS:45e3}).then(e=>(console.log("MongoDB connected successfully"),e)).catch(e=>{throw console.error("MongoDB connection error:",e),n.promise=null,e}));try{return n.conn=await n.promise,n.conn}catch(e){throw n.promise=null,e}}},93330:(e,t,r)=>{r.r(t),r.d(t,{default:()=>p});var i=r(11185),o=r.n(i),s=r(42023),n=r.n(s);let a=new(o()).Schema({name:{type:String,required:!0,trim:!0},email:{type:String,required:!0,unique:!0,lowercase:!0,trim:!0},password:{type:String,required:function(){return!this.googleId},minlength:6},googleId:{type:String,sparse:!0},role:{type:String,enum:["author","reviewer","editor","copy-editor","admin"],default:"author"},roles:[{type:String,enum:["author","reviewer","editor","copy-editor","admin"]}],currentActiveRole:{type:String,enum:["author","reviewer","editor","copy-editor","admin"]},isFounder:{type:Boolean,default:!1},profileImage:{type:String,default:""},affiliation:{type:String,default:""},country:{type:String,default:""},bio:{type:String,default:""},expertise:[{type:String}],orcid:{type:String,default:""},designation:{type:String,default:""},designationRole:{type:String,default:""},isEmailVerified:{type:Boolean,default:!1},twoFactorEnabled:{type:Boolean,default:!1},twoFactorSecret:{type:String},resetPasswordToken:{type:String},resetPasswordExpires:{type:Date},emailVerificationToken:{type:String}},{timestamps:!0});a.pre("save",async function(e){if(this.isModified("password")&&this.password)try{let e=await n().genSalt(12);this.password=await n().hash(this.password,e)}catch(t){return e(t)}this.role||(this.role="author"),this.roles&&Array.isArray(this.roles)||(this.roles=[]),0===this.roles.length&&(this.roles=[this.role]),this.currentActiveRole||(this.currentActiveRole=this.role),this.roles.includes(this.currentActiveRole)||this.roles.push(this.currentActiveRole),!this.designation||this.roles.includes("editor")||this.roles.includes("reviewer")||(this.designation="",this.designationRole=""),e()}),a.methods.comparePassword=async function(e){return!!this.password&&n().compare(e,this.password)},a.methods.toJSON=function(){let e=this.toObject();return delete e.password,delete e.twoFactorSecret,delete e.resetPasswordToken,delete e.emailVerificationToken,e};let p=o().models.User||o().model("User",a)}};var t=require("../../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[9276,5972,2023,1734,5245,9485],()=>r(84884));module.exports=i})();