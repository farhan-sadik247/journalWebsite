"use strict";(()=>{var e={};e.id=611,e.ids=[611,9121],e.modules={11185:e=>{e.exports=require("mongoose")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},27790:e=>{e.exports=require("assert")},78893:e=>{e.exports=require("buffer")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},80665:e=>{e.exports=require("dns")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},98216:e=>{e.exports=require("net")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},86624:e=>{e.exports=require("querystring")},76162:e=>{e.exports=require("stream")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},17293:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>v,patchFetch:()=>b,requestAsyncStorage:()=>m,routeModule:()=>y,serverHooks:()=>h,staticGenerationAsyncStorage:()=>f});var i={};r.r(i),r.d(i,{POST:()=>g});var o=r(49303),a=r(88716),n=r(60670),s=r(87070),p=r(45609),d=r(85517),l=r(14184),u=r(19121),c=r(20471);async function g(e,{params:t}){try{let i=await (0,p.getServerSession)(d.L);if(!i?.user)return s.NextResponse.json({error:"Unauthorized"},{status:401});let{approval:o,comments:a,files:n}=await e.json();if(!o)return s.NextResponse.json({error:"Approval status is required"},{status:400});await (0,l.Z)();let g=await u.default.findById(t.id).populate("submittedBy assignedCopyEditor");if(!g)return s.NextResponse.json({error:"Manuscript not found"},{status:404});let y=g.authors.some(e=>e.email===i.user.email),m=g.submittedBy._id.toString()===i.user.id;if(!y&&!m)return s.NextResponse.json({error:"Not authorized to review this manuscript"},{status:403});let f={authorCopyEditReview:{approval:o,comments:a||"",reviewedBy:i.user.id,reviewedAt:new Date,files:n||[]},lastModified:new Date};n&&n.length>0&&(f.latestManuscriptFiles=n.map(e=>({...e,type:"manuscript-final",version:`author-review-${new Date().toISOString()}`,isCurrentVersion:!0,uploadedAt:new Date}))),"approved"===o?(f.copyEditingStage="author-approved",f.status="ready-for-publication"):"revision-requested"===o&&(f.copyEditingStage="revision-needed",f.status="in-copy-editing");let h={event:`Author Copy-Edit Review: ${o}`,description:"approved"===o?"Author approved copy-edited version":"Author requested revisions to copy-edited version",date:new Date,performedBy:i.user.id,metadata:{approval:o,comments:a||"",filesUploaded:n?n.length:0}};f.$push={timeline:h};let v=await u.default.findByIdAndUpdate(t.id,f,{new:!0}).populate("submittedBy assignedCopyEditor");try{if(v.assignedCopyEditor?.email){let e=`Author Review Completed - ${v.title}`,t=`
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2>Author Copy-Edit Review Completed</h2>
            <p>Dear Copy Editor,</p>
            
            <p>The author has reviewed the copy-edited version of the manuscript "<strong>${v.title}</strong>".</p>
            
            <div style="background: ${"approved"===o?"#f0fdf4":"#fef2f2"}; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid ${"approved"===o?"#10b981":"#ef4444"};">
              <h3 style="margin: 0 0 10px 0; color: ${"approved"===o?"#065f46":"#991b1b"};">Review Result: ${"approved"===o?"Approved":"Revisions Requested"}</h3>
              ${a?`<p style="margin: 5px 0; color: #374151;"><strong>Author Comments:</strong><br>${a}</p>`:""}
              ${n&&n.length>0?`<p style="margin: 5px 0; color: #374151;"><strong>Files Attached:</strong> ${n.length} file(s)</p>`:""}
            </div>
            
            <p>Please check your copy editor dashboard for the next steps.</p>
            
            <p><a href="https://gjadt.org/dashboard/copy-editor/manuscripts/${v._id}" 
               style="background-color: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
               View Manuscript
            </a></p>
            
            <p>Best regards,<br>Editorial Team</p>
          </div>
        `;await (0,c.C)({to:v.assignedCopyEditor.email,subject:e,html:t})}if("approved"===o){let e=(await Promise.resolve().then(r.bind(r,93330))).default;for(let t of(await e.find({role:"editor"}).select("email name")))t.email&&await (0,c.C)({to:t.email,subject:`📖 Manuscript Ready for Publication - ${v.title}`,html:`
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                  <h2 style="color: #22c55e;">📖 Manuscript Ready for Publication</h2>
                  <p>Dear ${t.name||"Editor"},</p>
                  
                  <p>A manuscript has been approved by the author and is now ready for publication.</p>
                  
                  <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
                    <h3 style="margin: 0 0 10px 0; color: #065f46;">Manuscript Details</h3>
                    <p><strong>📄 Title:</strong> ${v.title}</p>
                    <p><strong>👤 Authors:</strong> ${v.authors.map(e=>e.name).join(", ")}</p>
                    <p><strong>📅 Approval Date:</strong> ${new Date().toLocaleDateString()}</p>
                    <p><strong>📂 Category:</strong> ${v.category}</p>
                    ${n&&n.length>0?`<p><strong>📎 Updated Files:</strong> ${n.length} file(s) ready for publication</p>`:""}
                  </div>
                  
                  <div style="background: #f1f5f9; padding: 15px; border-radius: 8px; margin: 20px 0;">
                    <h4 style="margin: 0 0 10px 0;">📋 Next Steps for Publication</h4>
                    <ul style="margin: 10px 0; padding-left: 20px;">
                      <li>Review the manuscript in the Publication Dashboard</li>
                      <li>Assign DOI and publication details</li>
                      <li>Schedule for publication in the appropriate issue</li>
                      <li>Download the latest author-approved files</li>
                    </ul>
                  </div>
                  
                  <p style="text-align: center; margin: 30px 0;">
                    <a href="https://gjadt.org/dashboard/publication" 
                       style="background-color: #22c55e; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold;">
                       📋 Open Publication Dashboard
                    </a>
                  </p>
                  
                  <p>Best regards,<br>Editorial Management System</p>
                </div>
              `})}for(let e of[process.env.ADMIN_EMAIL||"admin@journal.com"])await (0,c.C)({to:e,subject:`🔔 Author Copy-Edit Review Complete - ${v.title} ${"approved"===o?"(READY FOR PUBLICATION)":"(NEEDS REVISION)"}`,html:`
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2>🔔 Author Copy-Edit Review Complete</h2>
              <p><strong>Important:</strong> An author has completed their review of the copy-edited manuscript and action is required.</p>
              
              <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #e2e8f0;">
                <p><strong>📄 Manuscript:</strong> ${v.title}</p>
                <p><strong>👤 Author:</strong> ${v.submittedBy.name} (${v.submittedBy.email})</p>
                <p><strong>📅 Review Date:</strong> ${new Date().toLocaleDateString()}</p>
                <p><strong>✅ Status:</strong> ${"approved"===o?"APPROVED - Ready for Publication":"REVISIONS REQUESTED"}</p>
                ${a?`<p><strong>💬 Author Comments:</strong><br>"${a}"</p>`:""}
                ${n&&n.length>0?`<p><strong>📎 Updated Files:</strong> ${n.length} file(s) uploaded by author (use these for publication!)</p>`:""}
              </div>
              
              ${"approved"===o?`<div style="background: #f0fdf4; padding: 20px; border-radius: 8px; border-left: 4px solid #10b981; color: #065f46; margin: 20px 0;">
                  <h3 style="margin: 0 0 10px 0;">✅ MANUSCRIPT APPROVED - READY FOR PUBLICATION</h3>
                  <p style="margin: 5px 0;"><strong>Next Steps:</strong></p>
                  <ul style="margin: 10px 0; padding-left: 20px;">
                    <li>The author has approved the copy-edited version</li>
                    <li>Use the latest uploaded files for publication (stored in latestManuscriptFiles)</li>
                    <li>Coordinate with the appropriate editor to begin publication process</li>
                    <li>Notify the author once publication is complete</li>
                  </ul>
                </div>`:`<div style="background: #fef2f2; padding: 20px; border-radius: 8px; border-left: 4px solid #ef4444; color: #991b1b; margin: 20px 0;">
                  <h3 style="margin: 0 0 10px 0;">⚠️ REVISIONS REQUESTED BY AUTHOR</h3>
                  <p style="margin: 5px 0;"><strong>Next Steps:</strong></p>
                  <ul style="margin: 10px 0; padding-left: 20px;">
                    <li>Review the author's comments above</li>
                    <li>Coordinate with the copy editor to address the feedback</li>
                    <li>Make necessary revisions to the manuscript</li>
                    <li>Resubmit the updated version to the author for re-review</li>
                  </ul>
                </div>`}
              
              <div style="background: #f1f5f9; padding: 15px; border-radius: 8px; margin: 20px 0;">
                <h4 style="margin: 0 0 10px 0;">🎯 Administrative Actions Required:</h4>
                <p style="margin: 5px 0;">1. Assign or notify the appropriate handling editor</p>
                <p style="margin: 5px 0;">2. ${"approved"===o?"Begin publication workflow with updated files":"Coordinate revision process with copy editor"}</p>
                <p style="margin: 5px 0;">3. Update manuscript status in the system</p>
              </div>
              
              <p style="text-align: center; margin: 30px 0;">
                <a href="https://gjadt.org/dashboard/manuscripts/${v._id}" 
                   style="background-color: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold;">
                   📋 View Manuscript Details
                </a>
              </p>
              
              <hr style="margin: 30px 0; border: none; border-top: 1px solid #e2e8f0;">
              <p style="font-size: 12px; color: #64748b; text-align: center;">
                This is an automated notification from the Editorial Management System.<br>
                Please take appropriate action based on the author's review decision.
              </p>
            </div>
          `})}catch(e){console.log("Email notification failed (non-critical):",e)}return s.NextResponse.json({message:"Author review submitted successfully",manuscript:v})}catch(e){return console.error("Error submitting author review:",e),s.NextResponse.json({error:"Internal server error"},{status:500})}}let y=new o.AppRouteRouteModule({definition:{kind:a.x.APP_ROUTE,page:"/api/manuscripts/[id]/author-copy-edit-review/route",pathname:"/api/manuscripts/[id]/author-copy-edit-review",filename:"route",bundlePath:"app/api/manuscripts/[id]/author-copy-edit-review/route"},resolvedPagePath:"E:\\My Projects(personal)\\MyJournalWebsite\\journalWebsite\\src\\app\\api\\manuscripts\\[id]\\author-copy-edit-review\\route.ts",nextConfigOutput:"",userland:i}),{requestAsyncStorage:m,staticGenerationAsyncStorage:f,serverHooks:h}=y,v="/api/manuscripts/[id]/author-copy-edit-review/route";function b(){return(0,n.patchFetch)({serverHooks:h,staticGenerationAsyncStorage:f})}},20471:(e,t,r)=>{r.d(t,{C:()=>o,v:()=>a});let i=r(55245).createTransport({host:process.env.EMAIL_SERVER_HOST,port:parseInt(process.env.EMAIL_SERVER_PORT||"587"),secure:!1,auth:{user:process.env.EMAIL_SERVER_USER,pass:process.env.EMAIL_SERVER_PASSWORD}});async function o(e){try{return await i.sendMail({from:process.env.EMAIL_FROM,to:Array.isArray(e.to)?e.to.join(", "):e.to,subject:e.subject,html:e.html,text:e.text,attachments:e.attachments}),{success:!0}}catch(e){return console.error("Error sending email:",e),{success:!1,error:e}}}let a={manuscriptSubmitted:(e,t,r)=>({subject:"Manuscript Submission Confirmation",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Manuscript Submission Confirmation</h2>
        <p>Dear ${e},</p>
        <p>Thank you for submitting your manuscript to our journal. Your submission has been received and is now under review.</p>
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">Manuscript Details:</h3>
          <p style="margin: 5px 0;"><strong>Title:</strong> ${t}</p>
          <p style="margin: 5px 0;"><strong>Manuscript ID:</strong> ${r}</p>
          <p style="margin: 5px 0;"><strong>Status:</strong> Under Review</p>
        </div>
        <p>You will receive updates on the review process via email. You can also track the status of your submission by logging into your account.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),reviewerInvitation:(e,t,r)=>({subject:"Invitation to Review Manuscript",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Review Invitation</h2>
        <p>Dear ${e},</p>
        <p>You have been invited to review the following manuscript:</p>
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">${t}</h3>
          <p style="margin: 5px 0;"><strong>Review Due Date:</strong> ${r}</p>
        </div>
        <p>Please log into your account to accept or decline this review invitation.</p>
        <p>Thank you for your contribution to the peer review process.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),reviewCompleted:(e,t,r)=>({subject:"Review Completed - Decision Available",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Review Decision Available</h2>
        <p>Dear ${e},</p>
        <p>The peer review for your manuscript has been completed.</p>
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">${t}</h3>
          <p style="margin: 5px 0;"><strong>Decision:</strong> ${r}</p>
        </div>
        <p>Please log into your account to view the detailed review comments and next steps.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),manuscriptAccepted:(e,t)=>({subject:"Manuscript Accepted for Publication",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #10b981;">Manuscript Accepted!</h2>
        <p>Dear ${e},</p>
        <p>Congratulations! Your manuscript has been accepted for publication.</p>
        <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981;">
          <h3 style="margin: 0 0 10px 0; color: #374151;">${t}</h3>
          <p style="margin: 5px 0; color: #065f46;"><strong>Status:</strong> Accepted</p>
        </div>
        <p>Your manuscript will now proceed to the production phase. We will contact you with further details regarding publication timeline and final proofs.</p>
        <p>Thank you for choosing our journal for your research publication.</p>
        <p>Best regards,<br>Editorial Team</p>
      </div>
    `}),contactMessage:(e,t,r,i)=>({subject:`New Contact Message: ${r}`,html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">New Contact Message Received</h2>
        
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 15px 0; color: #374151;">Contact Information:</h3>
          <p style="margin: 5px 0;"><strong>Name:</strong> ${e}</p>
          <p style="margin: 5px 0;"><strong>Email:</strong> ${t}</p>
          <p style="margin: 5px 0;"><strong>Subject:</strong> ${r}</p>
          <p style="margin: 5px 0;"><strong>Date:</strong> ${new Date().toLocaleString()}</p>
        </div>
        
        <div style="background: #ffffff; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #e5e7eb;">
          <h3 style="margin: 0 0 15px 0; color: #374151;">Message:</h3>
          <p style="white-space: pre-wrap; line-height: 1.6;">${i}</p>
        </div>
        
        <div style="background: #eff6ff; padding: 15px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0; color: #1e40af;">
            <strong>Note:</strong> Please log into the admin dashboard to respond to this message.
          </p>
        </div>
        
        <p style="margin-top: 30px;">
          Best regards,<br>
          Journal Website System
        </p>
      </div>
    `})}},14184:(e,t,r)=>{r.d(t,{Z:()=>s});var i=r(11185),o=r.n(i);let a="mongodb+srv://fsadik2319:v17Ad1JygFqbVPWd@journalweb1.oeyvwhv.mongodb.net/?retryWrites=true&w=majority&appName=journalweb1";if(!a)throw Error("Please define the MONGODB_URI environment variable inside .env.local");let n=global.mongoose;n||(n=global.mongoose={conn:null,promise:null});let s=async function(){if(n.conn){if(1===o().connection.readyState)return n.conn;n.conn=null,n.promise=null}n.promise||(console.log("Connecting to MongoDB..."),n.promise=o().connect(a,{bufferCommands:!1,serverSelectionTimeoutMS:5e3,connectTimeoutMS:1e4,socketTimeoutMS:45e3}).then(e=>(console.log("MongoDB connected successfully"),e)).catch(e=>{throw console.error("MongoDB connection error:",e),n.promise=null,e}));try{return n.conn=await n.promise,n.conn}catch(e){throw n.promise=null,e}}},19121:(e,t,r)=>{r.d(t,{default:()=>d});var i=r(11185),o=r.n(i);let a=new(o()).Schema({name:{type:String,required:!0},email:{type:String,required:!0},affiliation:{type:String,required:!0},orcid:{type:String,default:""},isCorresponding:{type:Boolean,default:!1}},{_id:!1}),n=new(o()).Schema({filename:{type:String,required:!0},originalName:{type:String,required:!0},cloudinaryId:{type:String,required:!1},storageId:{type:String,required:!1},url:{type:String,required:!0},type:{type:String,enum:["manuscript","supplement","figure","table","revision"],required:!0},size:{type:Number,required:!0},version:{type:Number,default:1},uploadDate:{type:Date,default:Date.now}}),s=new(o()).Schema({event:{type:String,required:!0},description:{type:String,required:!0},date:{type:Date,default:Date.now},performedBy:{type:o().Schema.Types.ObjectId,ref:"User",required:!0},metadata:{type:o().Schema.Types.Mixed,default:{}}}),p=new(o()).Schema({title:{type:String,required:!0,trim:!0},abstract:{type:String,required:!0},keywords:[{type:String,required:!0}],authors:[a],correspondingAuthor:{type:String,required:!0},submittedBy:{type:o().Schema.Types.ObjectId,ref:"User",required:!0},files:[n],status:{type:String,enum:["submitted","under-review","revision-requested","major-revision-requested","minor-revision-requested","under-editorial-review","reviewed","accepted","accepted-awaiting-copy-edit","in-copy-editing","copy-editing-complete","ready-for-publication","rejected","payment-required","payment-submitted","in-production","published"],default:"submitted"},requiresPayment:{type:Boolean,default:!1},paymentStatus:{type:String,enum:["not-required","pending","processing","completed","failed","waived"],default:"not-required"},apcAmount:{type:Number,default:0,min:0},paymentDeadline:{type:Date},reviewType:{type:String,enum:["single-blind","double-blind"],default:"single-blind"},currentVersion:{type:Number,default:1},submissionDate:{type:Date,default:Date.now},lastModified:{type:Date,default:Date.now},reviewDeadline:{type:Date},category:{type:String,required:!0},funding:{type:String,default:""},conflictOfInterest:{type:String,default:""},ethicsStatement:{type:String,default:""},dataAvailability:{type:String,default:""},reviewerSuggestions:[{type:String}],reviewerExclusions:[{type:String}],timeline:[s],doi:{type:String,unique:!0,sparse:!0},volume:{type:Number},issue:{type:Number},pages:{type:String},publishedDate:{type:Date},metrics:{views:{type:Number,default:0},downloads:{type:Number,default:0},citations:{type:Number,default:0}},copyEditingStage:{type:String,enum:["copy-editing","author-review","author-approved","ready-for-production"]},productionStage:{type:String,enum:["not-started","in-progress","completed"],default:"not-started"},assignedCopyEditor:{type:o().Schema.Types.ObjectId,ref:"User"},assignedEditor:{type:o().Schema.Types.ObjectId,ref:"User"},copyEditingDueDate:{type:Date},copyEditingNotes:{type:String,default:""},copyEditingStartDate:{type:Date},copyEditingCompletedDate:{type:Date},copyEditReview:{copyEditorId:{type:o().Schema.Types.ObjectId,ref:"User"},copyEditorName:{type:String},copyEditorEmail:{type:String},comments:{type:String,required:function(){return this.copyEditReview&&this.copyEditReview.submittedAt}},galleyProofUrl:{type:String},galleyProofPublicId:{type:String},galleyProofFilename:{type:String},completionStatus:{type:String,enum:["completed","needs-revision"]},submittedAt:{type:Date},stage:{type:String,default:"copy-edit-review"}},authorCopyEditReview:{approval:{type:String,enum:["approved","revision-requested"]},comments:{type:String},reviewedAt:{type:Date},reviewedBy:{type:o().Schema.Types.ObjectId,ref:"User"},files:[{originalName:{type:String,required:!0},filename:{type:String,required:!0},url:{type:String,required:!0},type:{type:String,default:"author-review-file"},uploadedBy:{type:o().Schema.Types.ObjectId,ref:"User"},uploadedAt:{type:Date,default:Date.now},size:{type:Number},mimeType:{type:String}}]},copyEditWorkingFiles:[{originalName:{type:String,required:!0},filename:{type:String,required:!0},url:{type:String,required:!0},size:{type:Number,required:!0},type:{type:String,required:!0},uploadedBy:{type:String,required:!0},uploadedAt:{type:Date,default:Date.now}}],copyEditorAssignment:{copyEditorId:{type:o().Schema.Types.ObjectId,ref:"User"},copyEditorName:{type:String},copyEditorEmail:{type:String},assignedBy:{type:o().Schema.Types.ObjectId,ref:"User"},assignedByName:{type:String},assignedDate:{type:Date},dueDate:{type:Date},status:{type:String,enum:["assigned","in-progress","galley-submitted","approved-by-author","confirmed-by-copy-editor"],default:"assigned"},notes:{type:String,default:""},completedDate:{type:Date},authorApprovalDate:{type:Date},galleyProofs:[{filename:{type:String,required:!0},originalName:{type:String,required:!0},cloudinaryId:{type:String,required:!1},storageId:{type:String,required:!1},url:{type:String,required:!0},type:{type:String,enum:["galley-proof","typeset-manuscript","final-pdf"],default:"galley-proof"},size:{type:Number,required:!0},uploadedAt:{type:Date,default:Date.now}}],galleySubmissionDate:{type:Date},galleyNotes:{type:String,default:""},authorApproval:{approved:{type:Boolean,default:!1},approvedAt:{type:Date},comments:{type:String,default:""}},copyEditorConfirmation:{confirmed:{type:Boolean,default:!1},confirmedAt:{type:Date},reportToEditor:{type:String,default:""},finalNotes:{type:String,default:""}}},latestManuscriptFiles:[{originalName:{type:String,required:!0},filename:{type:String,required:!0},url:{type:String,required:!0},type:{type:String,default:"manuscript-final"},uploadedBy:{type:o().Schema.Types.ObjectId,ref:"User"},uploadedAt:{type:Date,default:Date.now},size:{type:Number},mimeType:{type:String},version:{type:String,default:"author-review-v1"},isCurrentVersion:{type:Boolean,default:!0}}]},{timestamps:!0});p.index({title:"text",abstract:"text",keywords:"text","authors.name":"text"}),p.index({category:1,status:1}),p.index({submissionDate:-1}),p.index({publishedDate:-1}),p.pre("save",function(e){this.lastModified=new Date,e()});let d=o().models.Manuscript||o().model("Manuscript",p)},93330:(e,t,r)=>{r.r(t),r.d(t,{default:()=>p});var i=r(11185),o=r.n(i),a=r(42023),n=r.n(a);let s=new(o()).Schema({name:{type:String,required:!0,trim:!0},email:{type:String,required:!0,unique:!0,lowercase:!0,trim:!0},password:{type:String,required:function(){return!this.googleId},minlength:6},googleId:{type:String,sparse:!0},role:{type:String,enum:["author","reviewer","editor","copy-editor","admin"],default:"author"},roles:[{type:String,enum:["author","reviewer","editor","copy-editor","admin"]}],currentActiveRole:{type:String,enum:["author","reviewer","editor","copy-editor","admin"]},isFounder:{type:Boolean,default:!1},profileImage:{type:String,default:""},affiliation:{type:String,default:""},country:{type:String,default:""},bio:{type:String,default:""},expertise:[{type:String}],orcid:{type:String,default:""},designation:{type:String,default:""},designationRole:{type:String,default:""},isEmailVerified:{type:Boolean,default:!1},twoFactorEnabled:{type:Boolean,default:!1},twoFactorSecret:{type:String},resetPasswordToken:{type:String},resetPasswordExpires:{type:Date},emailVerificationToken:{type:String}},{timestamps:!0});s.pre("save",async function(e){if(this.isModified("password")&&this.password)try{let e=await n().genSalt(12);this.password=await n().hash(this.password,e)}catch(t){return e(t)}this.role||(this.role="author"),this.roles&&Array.isArray(this.roles)||(this.roles=[]),0===this.roles.length&&(this.roles=[this.role]),this.currentActiveRole||(this.currentActiveRole=this.role),this.roles.includes(this.currentActiveRole)||this.roles.push(this.currentActiveRole),!this.designation||this.roles.includes("editor")||this.roles.includes("reviewer")||(this.designation="",this.designationRole=""),e()}),s.methods.comparePassword=async function(e){return!!this.password&&n().compare(e,this.password)},s.methods.toJSON=function(){let e=this.toObject();return delete e.password,delete e.twoFactorSecret,delete e.resetPasswordToken,delete e.emailVerificationToken,e};let p=o().models.User||o().model("User",s)},85517:(e,t,r)=>{r.d(t,{L:()=>d});var i=r(75571),o=r.n(i),a=r(77234),n=r(53797),s=r(14184),p=r(93330);console.log("NextAuth Configuration:",{environment:"production",baseUrl:"https://gjadt.org",hasGoogleCredentials:!!(process.env.GOOGLE_CLIENT_ID&&process.env.GOOGLE_CLIENT_SECRET)});let d={providers:[(0,a.Z)({clientId:process.env.GOOGLE_CLIENT_ID,clientSecret:process.env.GOOGLE_CLIENT_SECRET,authorization:{params:{prompt:"consent",access_type:"offline",response_type:"code"}}}),(0,n.Z)({name:"credentials",credentials:{email:{label:"Email",type:"email"},password:{label:"Password",type:"password"}},async authorize(e){if(!e?.email||!e?.password)return null;try{await (0,s.Z)();let t=await p.default.findOne({email:e.email});if(!t||!t.comparePassword||!await t.comparePassword(e.password))return null;return{id:t._id.toString(),email:t.email,name:t.name,role:t.role,roles:t.roles||["author"],currentActiveRole:t.currentActiveRole||t.role||"author",isFounder:t.isFounder||!1,image:t.profileImage}}catch(e){return console.error("Auth error:",e),null}}})],callbacks:{async signIn({user:e,account:t,profile:r}){if(t?.provider==="google")try{await (0,s.Z)();let r=await p.default.findOne({email:e.email});r?r.googleId||(r.googleId=t.providerAccountId,r.isEmailVerified=!0,r.profileImage||(r.profileImage=e.image),await r.save()):r=await p.default.create({name:e.name,email:e.email,googleId:t.providerAccountId,profileImage:e.image,isEmailVerified:!0,role:"author",roles:["author"],currentActiveRole:"author",isFounder:!1}),e.role=r.role,e.roles=r.roles||["author"],e.currentActiveRole=r.currentActiveRole||r.role||"author",e.isFounder=r.isFounder||!1,e.id=r._id.toString()}catch(e){return console.error("Google sign in error:",e),!1}return!0},async jwt({token:e,user:t,account:r,trigger:i,session:o}){if(t&&(e.role=t.role,e.roles=t.roles,e.currentActiveRole=t.currentActiveRole,e.isFounder=t.isFounder,e.id=t.id),"update"===i&&o?.user?.currentActiveRole)try{await (0,s.Z)();let t=await p.default.findById(e.id);t&&(e.role=t.role,e.roles=t.roles,e.currentActiveRole=t.currentActiveRole,e.isFounder=t.isFounder)}catch(e){console.error("Error refreshing user data in JWT callback:",e)}return e},session:async({session:e,token:t})=>(t&&e.user&&(e.user.id=t.id,e.user.role=t.role,e.user.roles=t.roles,e.user.currentActiveRole=t.currentActiveRole,e.user.isFounder=t.isFounder),e)},pages:{signIn:"/auth/signin"},session:{strategy:"jwt"},secret:"aIf0YRSciO8zGwSSN98K1VjdrDrtd7jw5au0Y1v/lWM="};o()(d)}};var t=require("../../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[9276,5972,2023,1734,5245],()=>r(17293));module.exports=i})();